import React from 'react';
import { 
  AppBar, 
  Toolbar, 
  Typography, 
  Button, 
  Container, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  CardActions,
  TextField,
  Paper,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  RadioGroup,
  Radio,
  FormControlLabel
} from '@mui/material';
import { 
  Search as SearchIcon,
  WhatsApp as WhatsAppIcon,
  AccessTime as AccessTimeIcon,
  Warning as WarningIcon
} from '@mui/icons-material';

export default function Services() {
  const [language, setLanguage] = React.useState('fr');
  const [category, setCategory] = React.useState('all');
  const [location, setLocation] = React.useState('all');
  const [urgency, setUrgency] = React.useState('any');
  const [visibility, setVisibility] = React.useState('24');
  const [contactPreference, setContactPreference] = React.useState('both');

  const handleLanguageChange = (event) => {
    setLanguage(event.target.value);
  };

  const handleCategoryChange = (event) => {
    setCategory(event.target.value);
  };

  const handleLocationChange = (event) => {
    setLocation(event.target.value);
  };

  const handleUrgencyChange = (event) => {
    setUrgency(event.target.value);
  };

  const handleVisibilityChange = (event) => {
    setVisibility(event.target.value);
  };

  const handleContactPreferenceChange = (event) => {
    setContactPreference(event.target.value);
  };

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Congo Diaspora Platform
          </Typography>
          
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
              <Select
                value={language}
                onChange={handleLanguageChange}
                displayEmpty
                sx={{ color: 'white' }}
              >
                <MenuItem value="fr">Français</MenuItem>
                <MenuItem value="ln">Lingala</MenuItem>
                <MenuItem value="en">English</MenuItem>
                <MenuItem value="sw">Swahili</MenuItem>
                <MenuItem value="lu">Tshiluba</MenuItem>
              </Select>
            </FormControl>
            
            <Button color="inherit">
              <SearchIcon sx={{ mr: 1 }} />
              Search
            </Button>
            
            <Button color="inherit">Login</Button>
            <Button variant="contained" color="secondary">Sign Up</Button>
          </Box>
        </Toolbar>
      </AppBar>
      
      <Box sx={{ bgcolor: '#f5f5f5', py: 2 }}>
        <Container>
          <Grid container spacing={2}>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/">Home</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/communities">Communities</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/businesses">Businesses</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/exchange">Exchange</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth variant="contained" href="/services">Services</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/profile">My Profile</Button>
            </Grid>
          </Grid>
        </Container>
      </Box>
      
      {/* Service Request Header */}
      <Box sx={{ 
        bgcolor: 'primary.main', 
        color: 'white', 
        py: 4
      }}>
        <Container>
          <Typography variant="h3" component="h1" gutterBottom align="center">
            SERVICE REQUESTS
          </Typography>
          <Typography variant="h6" align="center" sx={{ maxWidth: 800, mx: 'auto' }}>
            Post time-limited service requests or respond to community needs
          </Typography>
        </Container>
      </Box>
      
      <Container sx={{ my: 4 }}>
        {/* Create Service Request Section */}
        <Paper sx={{ p: 3, mb: 4 }}>
          <Typography variant="h5" component="h2" gutterBottom>
            CREATE SERVICE REQUEST
          </Typography>
          
          <TextField
            fullWidth
            label="Title"
            placeholder="Enter your request title..."
            variant="outlined"
            sx={{ mb: 3 }}
          />
          
          <TextField
            fullWidth
            label="Description"
            placeholder="Describe what you're looking for in detail..."
            variant="outlined"
            multiline
            rows={4}
            sx={{ mb: 3 }}
          />
          
          <Grid container spacing={3} sx={{ mb: 3 }}>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Category</InputLabel>
                <Select
                  value={category}
                  onChange={handleCategoryChange}
                  label="Category"
                >
                  <MenuItem value="all">Select category</MenuItem>
                  <MenuItem value="housing">Housing</MenuItem>
                  <MenuItem value="finance">Financial Services</MenuItem>
                  <MenuItem value="education">Education</MenuItem>
                  <MenuItem value="healthcare">Healthcare</MenuItem>
                  <MenuItem value="legal">Legal Services</MenuItem>
                  <MenuItem value="admin">Administrative</MenuItem>
                  <MenuItem value="transportation">Transportation</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Location</InputLabel>
                <Select
                  value={location}
                  onChange={handleLocationChange}
                  label="Location"
                >
                  <MenuItem value="all">Select location</MenuItem>
                  <MenuItem value="kinshasa">Kinshasa</MenuItem>
                  <MenuItem value="lubumbashi">Lubumbashi</MenuItem>
                  <MenuItem value="goma">Goma</MenuItem>
                  <MenuItem value="bukavu">Bukavu</MenuItem>
                  <MenuItem value="kisangani">Kisangani</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Typography variant="subtitle1" gutterBottom>
                Urgency:
              </Typography>
              <Box sx={{ display: 'flex', gap: 2 }}>
                <FormControlLabel value="low" control={<Radio />} label="Low" />
                <FormControlLabel value="medium" control={<Radio />} label="Medium" />
                <FormControlLabel value="high" control={<Radio />} label="High" />
              </Box>
            </Grid>
          </Grid>
          
          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle1" gutterBottom>
              Visibility period:
            </Typography>
            <RadioGroup
              row
              value={visibility}
              onChange={handleVisibilityChange}
            >
              <FormControlLabel value="24" control={<Radio />} label="24 hours" />
              <FormControlLabel value="48" control={<Radio />} label="48 hours" />
              <FormControlLabel value="72" control={<Radio />} label="72 hours" />
            </RadioGroup>
          </Box>
          
          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle1" gutterBottom>
              Contact preference:
            </Typography>
            <RadioGroup
              row
              value={contactPreference}
              onChange={handleContactPreferenceChange}
            >
              <FormControlLabel value="platform" control={<Radio />} label="Platform messaging" />
              <FormControlLabel value="whatsapp" control={<Radio />} label="WhatsApp" />
              <FormControlLabel value="both" control={<Radio />} label="Both" />
            </RadioGroup>
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'center' }}>
            <Button variant="contained" color="secondary" size="large">
              POST REQUEST
            </Button>
          </Box>
        </Paper>
        
        {/* Filter and Sort Options */}
        <Paper sx={{ p: 3, mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            FILTER BY:
          </Typography>
          
          <Grid container spacing={2} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth>
                <InputLabel>Category</InputLabel>
                <Select
                  value={category}
                  onChange={handleCategoryChange}
                  label="Category"
                >
                  <MenuItem value="all">All Categories</MenuItem>
                  <MenuItem value="housing">Housing</MenuItem>
                  <MenuItem value="finance">Financial Services</MenuItem>
                  <MenuItem value="education">Education</MenuItem>
                  <MenuItem value="healthcare">Healthcare</MenuItem>
                  <MenuItem value="legal">Legal Services</MenuItem>
                  <MenuItem value="admin">Administrative</MenuItem>
                  <MenuItem value="transportation">Transportation</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth>
                <InputLabel>Location</InputLabel>
                <Select
                  value={location}
                  onChange={handleLocationChange}
                  label="Location"
                >
                  <MenuItem value="all">All Locations</MenuItem>
                  <MenuItem value="kinshasa">Kinshasa</MenuItem>
                  <MenuItem value="lubumbashi">Lubumbashi</MenuItem>
                  <MenuItem value="goma">Goma</MenuItem>
                  <MenuItem value="bukavu">Bukavu</MenuItem>
                  <MenuItem value="kisangani">Kisangani</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth>
                <InputLabel>Urgency</InputLabel>
                <Select
                  value={urgency}
                  onChange={handleUrgencyChange}
                  label="Urgency"
                >
                  <MenuItem value="any">Any Urgency</MenuItem>
                  <MenuItem value="high">High</MenuItem>
                  <MenuItem value="medium">Medium</MenuItem>
                  <MenuItem value="low">Low</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Box>
              <Typography variant="subtitle1" component="span" sx={{ mr: 2 }}>
                SORT BY:
              </Typography>
              <Button variant="contained" size="small" sx={{ mr: 1 }}>NEWEST</Button>
              <Button size="small" sx={{ mr: 1 }}>URGENCY</Button>
              <Button size="small">EXPIRING SOON</Button>
            </Box>
            
            <Button variant="contained">
              APPLY FILTERS
            </Button>
          </Box>
        </Paper>
        
        {/* Active Service Requests */}
        {[
          {
            urgency: "HIGH",
            expires: "18 hours",
            title: "Need reliable driver for business meetings in Kinshasa",
            description: "Looking for a professional driver familiar with Kinshasa who can provide transportation for business meetings over the next week. Must speak French and English, have a reliable vehicle, and knowledge of the business district. References required.",
            category: "Transportation",
            location: "Kinshasa",
            author: "Jean K.",
            time: "6 hours ago",
            responses: 5
          },
          {
            urgency: "MEDIUM",
            expires: "10 hours",
            title: "Seeking recommendations for international schools in Lubumbashi",
            description: "Returning with two children (ages 8 and 11) and need recommendations for international schools in Lubumbashi that offer French/English bilingual education. Preferably with IB curriculum or similar international standards.",
            category: "Education",
            location: "Lubumbashi",
            author: "Marie T.",
            time: "14 hours ago",
            responses: 8
          },
          {
            urgency: "MEDIUM",
            expires: "4 hours",
            title: "Need assistance with property documentation in Gombe",
            description: "Looking for someone experienced with property documentation who can help verify the legitimacy of land titles in the Gombe area. Need assistance with government offices and ensuring all paperwork is properly filed.",
            category: "Administrative",
            location: "Kinshasa (Gombe)",
            author: "Patrick M.",
            time: "20 hours ago",
            responses: 3
          }
        ].map((request, index) => (
          <Paper sx={{ p: 3, mb: 3 }} key={index}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
              <Chip 
                label={request.urgency + " URGENCY"} 
                color={request.urgency === "HIGH" ? "error" : "warning"} 
                size="small" 
              />
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <AccessTimeIcon fontSize="small" sx={{ mr: 0.5 }} />
                <Typography variant="body2">
                  Expires in: {request.expires}
                </Typography>
              </Box>
            </Box>
            
            <Typography variant="h6" component="h3" sx={{ mb: 1 }}>
              {request.title}
            </Typography>
            
            <Typography variant="body1" sx={{ mb: 2 }}>
              {request.description}
            </Typography>
            
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Category: {request.category} | Location: {request.location}<br />
              Posted by: {request.author} | {request.time}
            </Typography>
            
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
              <Button variant="text">{request.responses} responses</Button>
              <Button variant="contained">RESPOND VIA PLATFORM</Button>
              <Button 
                variant="outlined" 
                startIcon={<WhatsAppIcon />}
                color="success"
              >
                CONTACT VIA WHATSAPP
              </Button>
            </Box>
          </Paper>
        ))}
        
        {/* Pagination */}
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <Button variant="contained" size="small" sx={{ mx: 0.5 }}>1</Button>
          <Button size="small" sx={{ mx: 0.5 }}>2</Button>
          <Button size="small" sx={{ mx: 0.5 }}>3</Button>
          <Typography sx={{ mx: 0.5 }}>...</Typography>
          <Button size="small" sx={{ mx: 0.5 }}>Next &gt;</Button>
        </Box>
        
        {/* Service Request Guidelines */}
        <Paper sx={{ p: 4, mb: 4 }}>
          <Typography variant="h5" component="h3" gutterBottom>
            SERVICE REQUEST GUIDELINES
          </Typography>
          <Box component="ul" sx={{ pl: 4 }}>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Be specific about your needs and requirements</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Include relevant details like budget, timeline, and location</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Verify service providers before making any payments</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Meet in public places for initial consultations</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 2 }}>Report any suspicious behavior to platform moderators</Typography>
            </Box>
          </Box>
          <Button variant="outlined">
            VIEW FULL GUIDELINES
          </Button>
        </Paper>
        
        {/* My Service Requests Section */}
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h5" component="h3" gutterBottom>
            MY SERVICE REQUESTS
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
            <Button variant="contained">VIEW MY ACTIVE REQUESTS</Button>
            <Button variant="outlined">VIEW MY PAST REQUESTS</Button>
          </Box>
        </Paper>
      </Container>
      
      {/* Footer */}
      <Box sx={{ bgcolor: 'primary.dark', color: 'white', py: 6, mt: 8 }}>
        <Container>
          <Typography variant="h5" component="div" gutterBottom align="center">
            Congo Diaspora Platform
          </Typography>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">ABOUT US</Button>
            <Button color="inherit">CONTACT</Button>
            <Button color="inherit">PRIVACY POLICY</Button>
            <Button color="inherit">TERMS OF SERVICE</Button>
            <Button color="inherit">FAQ</Button>
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">FRANÇAIS</Button>
            <Button color="inherit">LINGALA</Button>
            <Button color="inherit">ENGLISH</Button>
            <Button color="inherit">SWAHILI</Button>
            <Button color="inherit">TSHILUBA</Button>
          </Box>
          
          <Typography variant="body2" align="center" sx={{ mt: 4 }}>
            © 2025 Congo Diaspora Platform. All rights reserved.
          </Typography>
        </Container>
      </Box>
    </>
  );
}
