import React from 'react';
import { 
  AppBar, 
  Toolbar, 
  Typography, 
  Button, 
  Container, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  CardActions, 
  CardMedia,
  Chip,
  Divider,
  Paper,
  IconButton,
  Menu,
  MenuItem,
  Select,
  FormControl,
  InputLabel
} from '@mui/material';
import { 
  Search as SearchIcon, 
  Language as LanguageIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon,
  WhatsApp as WhatsAppIcon,
  AccessTime as AccessTimeIcon,
  LocationOn as LocationOnIcon,
  Star as StarIcon
} from '@mui/icons-material';

export default function Home() {
  const [language, setLanguage] = React.useState('fr');

  const handleLanguageChange = (event) => {
    setLanguage(event.target.value);
  };

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Congo Diaspora Platform
          </Typography>
          
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
              <Select
                value={language}
                onChange={handleLanguageChange}
                displayEmpty
                sx={{ color: 'white' }}
              >
                <MenuItem value="fr">Français</MenuItem>
                <MenuItem value="ln">Lingala</MenuItem>
                <MenuItem value="en">English</MenuItem>
                <MenuItem value="sw">Swahili</MenuItem>
                <MenuItem value="lu">Tshiluba</MenuItem>
              </Select>
            </FormControl>
            
            <IconButton color="inherit">
              <SearchIcon />
            </IconButton>
            
            <Button color="inherit">Login</Button>
            <Button variant="contained" color="secondary">Sign Up</Button>
          </Box>
        </Toolbar>
      </AppBar>
      
      <Box sx={{ bgcolor: '#f5f5f5', py: 2 }}>
        <Container>
          <Grid container spacing={2}>
            <Grid item xs={12} md={2}>
              <Button fullWidth variant="contained">Home</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth>Communities</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth>Businesses</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth>Exchange</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth>Services</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth>My Profile</Button>
            </Grid>
          </Grid>
        </Container>
      </Box>
      
      {/* Hero Section */}
      <Box sx={{ 
        bgcolor: 'primary.main', 
        color: 'white', 
        py: 8,
        backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("/hero-bg.jpg")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}>
        <Container>
          <Typography variant="h2" component="h1" gutterBottom align="center">
            WELCOME TO THE CONGO DIASPORA PLATFORM
          </Typography>
          <Typography variant="h5" paragraph align="center">
            Connecting professionals returning home with trusted resources and community support
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
            <Button variant="contained" color="secondary" size="large" sx={{ mr: 2 }}>
              SIGN UP
            </Button>
            <Button variant="outlined" sx={{ color: 'white', borderColor: 'white' }} size="large">
              LEARN MORE
            </Button>
          </Box>
        </Container>
      </Box>
      
      {/* Featured Services Section */}
      <Container sx={{ my: 8 }}>
        <Typography variant="h4" component="h2" gutterBottom align="center">
          ESSENTIAL SERVICES FOR RETURNING PROFESSIONALS
        </Typography>
        
        <Grid container spacing={4} sx={{ mt: 4 }}>
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h5" component="h3" gutterBottom align="center">
                  HOUSING ASSISTANCE
                </Typography>
                <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
                  <Box sx={{ 
                    width: 80, 
                    height: 80, 
                    borderRadius: '50%', 
                    bgcolor: 'primary.light',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <HomeIcon fontSize="large" />
                  </Box>
                </Box>
                <Typography variant="body1" align="center">
                  Find verified housing options with ratings and reviews from other diaspora members.
                </Typography>
              </CardContent>
              <CardActions sx={{ justifyContent: 'center' }}>
                <Button variant="contained">EXPLORE</Button>
              </CardActions>
            </Card>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h5" component="h3" gutterBottom align="center">
                  ADMINISTRATIVE SERVICES
                </Typography>
                <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
                  <Box sx={{ 
                    width: 80, 
                    height: 80, 
                    borderRadius: '50%', 
                    bgcolor: 'primary.light',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <DescriptionIcon fontSize="large" />
                  </Box>
                </Box>
                <Typography variant="body1" align="center">
                  Navigate government procedures with step-by-step guides and recommended service providers.
                </Typography>
              </CardContent>
              <CardActions sx={{ justifyContent: 'center' }}>
                <Button variant="contained">EXPLORE</Button>
              </CardActions>
            </Card>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h5" component="h3" gutterBottom align="center">
                  FINANCIAL SERVICES
                </Typography>
                <Box sx={{ display: 'flex', justifyContent: 'center', my: 2 }}>
                  <Box sx={{ 
                    width: 80, 
                    height: 80, 
                    borderRadius: '50%', 
                    bgcolor: 'primary.light',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <AccountBalanceIcon fontSize="large" />
                  </Box>
                </Box>
                <Typography variant="body1" align="center">
                  Access trusted financial resources, currency exchange, and investment opportunities.
                </Typography>
              </CardContent>
              <CardActions sx={{ justifyContent: 'center' }}>
                <Button variant="contained">EXPLORE</Button>
              </CardActions>
            </Card>
          </Grid>
        </Grid>
      </Container>
      
      {/* Active Requests Section */}
      <Box sx={{ bgcolor: '#f5f5f5', py: 6 }}>
        <Container>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
            <Typography variant="h4" component="h2">
              ACTIVE SERVICE REQUESTS
            </Typography>
            <Button>VIEW ALL</Button>
          </Box>
          
          <Grid container spacing={3}>
            {[1, 2, 3].map((item) => (
              <Grid item xs={12} key={item}>
                <Paper sx={{ p: 3 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <Chip 
                      icon={<AccessTimeIcon />} 
                      label="24h" 
                      color="secondary" 
                      size="small" 
                      sx={{ mr: 2 }} 
                    />
                    <Typography variant="h6">
                      {item === 1 && "Looking for reliable real estate agent in Kinshasa"}
                      {item === 2 && "Need recommendations for international schools in Lubumbashi"}
                      {item === 3 && "Seeking financial advisor with diaspora experience"}
                    </Typography>
                  </Box>
                  
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    Posted by: {item === 1 ? "Jean K." : item === 2 ? "Marie T." : "Patrick M."} | 
                    {item === 1 ? " 4 hours ago" : item === 2 ? " 8 hours ago" : " 12 hours ago"} | 
                    {item === 1 ? " 3 responses" : item === 2 ? " 5 responses" : " 2 responses"}
                  </Typography>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <Button 
                      variant="outlined" 
                      startIcon={<WhatsAppIcon />}
                      sx={{ mr: 2 }}
                    >
                      Contact
                    </Button>
                    <Button variant="contained">
                      Respond
                    </Button>
                  </Box>
                </Paper>
              </Grid>
            ))}
          </Grid>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
            <Button variant="contained" color="secondary" size="large">
              POST A REQUEST
            </Button>
          </Box>
        </Container>
      </Box>
      
      {/* Top Communities Section */}
      <Container sx={{ my: 8 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
          <Typography variant="h4" component="h2">
            POPULAR COMMUNITIES
          </Typography>
          <Button>VIEW ALL</Button>
        </Box>
        
        <Grid container spacing={3}>
          {[
            { name: "r/Kinshasa", members: "15.2k" },
            { name: "r/Finance", members: "8.7k" },
            { name: "r/Healthcare", members: "6.3k" },
            { name: "r/Housing", members: "5.8k" },
            { name: "r/Education", members: "4.2k" },
            { name: "r/Culture", members: "3.9k" }
          ].map((community, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Card sx={{ height: '100%' }}>
                <CardContent>
                  <Typography variant="h6" component="h3" gutterBottom>
                    {community.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {community.members} members
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button variant="outlined" fullWidth>JOIN</Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
      
      {/* Top-Rated Businesses Section */}
      <Box sx={{ bgcolor: '#f5f5f5', py: 6 }}>
        <Container>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
            <Typography variant="h4" component="h2">
              TOP-RATED BUSINESSES
            </Typography>
            <Button>VIEW ALL</Button>
          </Box>
          
          <Grid container spacing={3}>
            {[
              { 
                name: "Congo Relocation Services", 
                rating: 4.9,
                category: "Housing",
                reviews: 127,
                quote: "Excellent service for returning professionals"
              },
              { 
                name: "Diaspora Financial Advisors", 
                rating: 4.7,
                category: "Financial Services",
                reviews: 98,
                quote: "Helped me navigate investment options back home"
              },
              { 
                name: "Express Document Services", 
                rating: 4.6,
                category: "Administrative",
                reviews: 112,
                quote: "Saved me weeks of bureaucratic hassle"
              }
            ].map((business, index) => (
              <Grid item xs={12} key={index}>
                <Paper sx={{ p: 3 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <Box sx={{ 
                      width: 50, 
                      height: 50, 
                      bgcolor: 'primary.main', 
                      color: 'white',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: 1,
                      mr: 2
                    }}>
                      {business.name.charAt(0)}
                    </Box>
                    <Box>
                      <Typography variant="h6">
                        {business.name}
                        {index === 0 && (
                          <Chip 
                            label="VERIFIED" 
                            size="small" 
                            color="success" 
                            sx={{ ml: 1 }} 
                          />
                        )}
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mr: 1 }}>
                          {[...Array(5)].map((_, i) => (
                            <StarIcon 
                              key={i} 
                              fontSize="small" 
                              sx={{ color: i < Math.floor(business.rating) ? 'gold' : 'gray' }} 
                            />
                          ))}
                        </Box>
                        <Typography variant="body2">
                          ({business.rating}) | {business.category} | {business.reviews} reviews
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                  
                  <Typography variant="body2" sx={{ my: 1, fontStyle: 'italic' }}>
                    "{business.quote}" - Recent review
                  </Typography>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <Button 
                      variant="contained" 
                      startIcon={<WhatsAppIcon />}
                      color="success"
                    >
                      CONTACT VIA WHATSAPP
                    </Button>
                  </Box>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>
      
      {/* Exchange Requests Section */}
      <Container sx={{ my: 8 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
          <Typography variant="h4" component="h2">
            CURRENCY EXCHANGE REQUESTS
          </Typography>
          <Button>VIEW ALL</Button>
        </Box>
        
        <Grid container spacing={3}>
          {[
            { from: "USD", to: "CDF", amount: "$500", rate: "2,450", location: "Kinshasa", time: "Today" },
            { from: "EUR", to: "CDF", amount: "€300", rate: "2,680", location: "Lubumbashi", time: "Tomorrow" },
            { from: "CDF", to: "USD", amount: "CDF 850,000", rate: "2,430", location: "Kinshasa", time: "Today" }
          ].map((exchange, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Card sx={{ height: '100%' }}>
                <CardContent>
                  <Typography variant="h6" component="h3" gutterBottom align="center">
                    {exchange.from} → {exchange.to}
                  </Typography>
                  
                  <Box sx={{ my: 2, textAlign: 'center' }}>
                    <Typography variant="h5" gutterBottom>
                      {exchange.amount}
                    </Typography>
                    <Typography variant="body1">
                      Rate: {exchange.rate}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                    <LocationOnIcon fontSize="small" sx={{ mr: 0.5 }} />
                    <Typography variant="body2">
                      {exchange.location}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <AccessTimeIcon fontSize="small" sx={{ mr: 0.5 }} />
                    <Typography variant="body2">
                      {exchange.time}
                    </Typography>
                  </Box>
                </CardContent>
                <CardActions sx={{ justifyContent: 'center' }}>
                  <Button variant="contained">CONTACT</Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
        
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <Button variant="contained" color="secondary" size="large">
            POST EXCHANGE REQUEST
          </Button>
        </Box>
      </Container>
      
      {/* Footer */}
      <Box sx={{ bgcolor: 'primary.dark', color: 'white', py: 6, mt: 8 }}>
        <Container>
          <Typography variant="h5" component="div" gutterBottom align="center">
            Congo Diaspora Platform
          </Typography>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">ABOUT US</Button>
            <Button color="inherit">CONTACT</Button>
            <Button color="inherit">PRIVACY POLICY</Button>
            <Button color="inherit">TERMS OF SERVICE</Button>
            <Button color="inherit">FAQ</Button>
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">FRANÇAIS</Button>
            <Button color="inherit">LINGALA</Button>
            <Button color="inherit">ENGLISH</Button>
            <Button color="inherit">SWAHILI</Button>
            <Button color="inherit">TSHILUBA</Button>
          </Box>
          
          <Typography variant="body2" align="center" sx={{ mt: 4 }}>
            © 2025 Congo Diaspora Platform. All rights reserved.
          </Typography>
        </Container>
      </Box>
    </>
  );
}

// Icons that were referenced but not imported
const HomeIcon = () => <Box>🏠</Box>;
const DescriptionIcon = () => <Box>📄</Box>;
const AccountBalanceIcon = () => <Box>🏦</Box>;
