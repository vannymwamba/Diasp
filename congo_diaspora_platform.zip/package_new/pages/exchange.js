import React from 'react';
import { 
  AppBar, 
  Toolbar, 
  Typography, 
  Button, 
  Container, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  CardActions,
  TextField,
  Paper,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  RadioGroup,
  Radio,
  FormControlLabel
} from '@mui/material';
import { 
  Search as SearchIcon,
  WhatsApp as WhatsAppIcon,
  AccessTime as AccessTimeIcon,
  LocationOn as LocationOnIcon,
  Warning as WarningIcon
} from '@mui/icons-material';

export default function Exchange() {
  const [language, setLanguage] = React.useState('fr');
  const [exchangeType, setExchangeType] = React.useState('buy');
  const [fromCurrency, setFromCurrency] = React.useState('usd');
  const [toCurrency, setToCurrency] = React.useState('cdf');
  const [location, setLocation] = React.useState('kinshasa');
  const [expiration, setExpiration] = React.useState('24');
  
  // Filter states
  const [filterExchangeType, setFilterExchangeType] = React.useState('all');
  const [filterCurrencyPair, setFilterCurrencyPair] = React.useState('all');
  const [filterLocation, setFilterLocation] = React.useState('all');
  const [sortBy, setSortBy] = React.useState('newest');

  const handleLanguageChange = (event) => {
    setLanguage(event.target.value);
  };

  const handleExchangeTypeChange = (event) => {
    setExchangeType(event.target.value);
  };

  const handleFromCurrencyChange = (event) => {
    setFromCurrency(event.target.value);
  };

  const handleToCurrencyChange = (event) => {
    setToCurrency(event.target.value);
  };

  const handleLocationChange = (event) => {
    setLocation(event.target.value);
  };

  const handleExpirationChange = (event) => {
    setExpiration(event.target.value);
  };
  
  const handleFilterExchangeTypeChange = (event) => {
    setFilterExchangeType(event.target.value);
  };
  
  const handleFilterCurrencyPairChange = (event) => {
    setFilterCurrencyPair(event.target.value);
  };
  
  const handleFilterLocationChange = (event) => {
    setFilterLocation(event.target.value);
  };
  
  const handleSortByChange = (event) => {
    setSortBy(event.target.value);
  };

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Congo Diaspora Platform
          </Typography>
          
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
              <Select
                value={language}
                onChange={handleLanguageChange}
                displayEmpty
                sx={{ color: 'white' }}
              >
                <MenuItem value="fr">Français</MenuItem>
                <MenuItem value="ln">Lingala</MenuItem>
                <MenuItem value="en">English</MenuItem>
                <MenuItem value="sw">Swahili</MenuItem>
                <MenuItem value="lu">Tshiluba</MenuItem>
              </Select>
            </FormControl>
            
            <Button color="inherit">
              <SearchIcon sx={{ mr: 1 }} />
              Search
            </Button>
            
            <Button color="inherit">Login</Button>
            <Button variant="contained" color="secondary">Sign Up</Button>
          </Box>
        </Toolbar>
      </AppBar>
      
      <Box sx={{ bgcolor: '#f5f5f5', py: 2 }}>
        <Container>
          <Grid container spacing={2}>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/">Home</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/communities">Communities</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/businesses">Businesses</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth variant="contained" href="/exchange">Exchange</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/services">Services</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/profile">My Profile</Button>
            </Grid>
          </Grid>
        </Container>
      </Box>
      
      {/* Exchange Request Header */}
      <Box sx={{ 
        bgcolor: 'primary.main', 
        color: 'white', 
        py: 4
      }}>
        <Container>
          <Typography variant="h3" component="h1" gutterBottom align="center">
            CURRENCY EXCHANGE
          </Typography>
          <Typography variant="h6" align="center" sx={{ maxWidth: 800, mx: 'auto' }}>
            Secure peer-to-peer currency exchange for the Congolese diaspora
          </Typography>
        </Container>
      </Box>
      
      <Container sx={{ my: 4 }}>
        {/* Create Exchange Request Section */}
        <Paper sx={{ p: 3, mb: 4 }}>
          <Typography variant="h5" component="h2" gutterBottom>
            CREATE EXCHANGE REQUEST
          </Typography>
          
          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle1" gutterBottom>
              Exchange Type:
            </Typography>
            <RadioGroup
              row
              value={exchangeType}
              onChange={handleExchangeTypeChange}
            >
              <FormControlLabel value="buy" control={<Radio />} label="Buy CDF" />
              <FormControlLabel value="sell" control={<Radio />} label="Sell CDF" />
            </RadioGroup>
          </Box>
          
          <Grid container spacing={3} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={6}>
              <Box sx={{ display: 'flex', alignItems: 'flex-end' }}>
                <FormControl sx={{ mr: 2, minWidth: 120 }}>
                  <InputLabel>From Currency</InputLabel>
                  <Select
                    value={fromCurrency}
                    onChange={handleFromCurrencyChange}
                    label="From Currency"
                  >
                    <MenuItem value="usd">USD</MenuItem>
                    <MenuItem value="eur">EUR</MenuItem>
                    <MenuItem value="gbp">GBP</MenuItem>
                    <MenuItem value="cdf">CDF</MenuItem>
                  </Select>
                </FormControl>
                <TextField
                  label="Amount"
                  variant="outlined"
                  fullWidth
                  placeholder="Enter amount"
                />
              </Box>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <Box sx={{ display: 'flex', alignItems: 'flex-end' }}>
                <FormControl sx={{ mr: 2, minWidth: 120 }}>
                  <InputLabel>To Currency</InputLabel>
                  <Select
                    value={toCurrency}
                    onChange={handleToCurrencyChange}
                    label="To Currency"
                  >
                    <MenuItem value="cdf">CDF</MenuItem>
                    <MenuItem value="usd">USD</MenuItem>
                    <MenuItem value="eur">EUR</MenuItem>
                    <MenuItem value="gbp">GBP</MenuItem>
                  </Select>
                </FormControl>
                <TextField
                  label="Amount"
                  variant="outlined"
                  fullWidth
                  placeholder="Calculated amount"
                  disabled
                />
              </Box>
            </Grid>
          </Grid>
          
          <TextField
            label="Proposed Rate"
            variant="outlined"
            fullWidth
            placeholder="Enter rate"
            sx={{ mb: 3 }}
          />
          
          <Grid container spacing={3} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Location</InputLabel>
                <Select
                  value={location}
                  onChange={handleLocationChange}
                  label="Location"
                >
                  <MenuItem value="kinshasa">Kinshasa</MenuItem>
                  <MenuItem value="lubumbashi">Lubumbashi</MenuItem>
                  <MenuItem value="goma">Goma</MenuItem>
                  <MenuItem value="bukavu">Bukavu</MenuItem>
                  <MenuItem value="kisangani">Kisangani</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <TextField
                label="Preferred Meeting Places"
                variant="outlined"
                fullWidth
                placeholder="Enter locations"
              />
            </Grid>
          </Grid>
          
          <TextField
            label="Available Times"
            variant="outlined"
            fullWidth
            placeholder="Select dates and times"
            sx={{ mb: 3 }}
          />
          
          <TextField
            label="Additional Notes"
            variant="outlined"
            fullWidth
            multiline
            rows={2}
            placeholder="Any specific requirements or conditions"
            sx={{ mb: 3 }}
          />
          
          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle1" gutterBottom>
              Expires After:
            </Typography>
            <RadioGroup
              row
              value={expiration}
              onChange={handleExpirationChange}
            >
              <FormControlLabel value="24" control={<Radio />} label="24 hours" />
              <FormControlLabel value="48" control={<Radio />} label="48 hours" />
              <FormControlLabel value="72" control={<Radio />} label="72 hours" />
            </RadioGroup>
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'center' }}>
            <Button variant="contained" color="secondary" size="large">
              POST EXCHANGE REQUEST
            </Button>
          </Box>
        </Paper>
        
        {/* Current Exchange Rates */}
        <Paper sx={{ p: 3, mb: 4 }}>
          <Typography variant="h5" component="h2" gutterBottom>
            CURRENT MARKET RATES
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={4}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body1">USD → CDF:</Typography>
                <Typography variant="body1" fontWeight="bold">2,450 - 2,480</Typography>
              </Box>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body1">EUR → CDF:</Typography>
                <Typography variant="body1" fontWeight="bold">2,670 - 2,700</Typography>
              </Box>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body1">GBP → CDF:</Typography>
                <Typography variant="body1" fontWeight="bold">3,120 - 3,150</Typography>
              </Box>
            </Grid>
          </Grid>
          
          <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
            Last updated: April 4, 2025 at 12:30 PM
          </Typography>
        </Paper>
        
        {/* Filter and Sort Options */}
        <Paper sx={{ p: 3, mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            FILTER BY:
          </Typography>
          
          <Grid container spacing={2} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth>
                <InputLabel>Exchange Type</InputLabel>
                <Select
                  value={filterExchangeType}
                  onChange={handleFilterExchangeTypeChange}
                  label="Exchange Type"
                >
                  <MenuItem value="all">All Types</MenuItem>
                  <MenuItem value="buy">Buy CDF</MenuItem>
                  <MenuItem value="sell">Sell CDF</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth>
                <InputLabel>Currency Pair</InputLabel>
                <Select
                  value={filterCurrencyPair}
                  onChange={handleFilterCurrencyPairChange}
                  label="Currency Pair"
                >
                  <MenuItem value="all">All Pairs</MenuItem>
                  <MenuItem value="usd-cdf">USD/CDF</MenuItem>
                  <MenuItem value="eur-cdf">EUR/CDF</MenuItem>
                  <MenuItem value="gbp-cdf">GBP/CDF</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth>
                <InputLabel>Location</InputLabel>
                <Select
                  value={filterLocation}
                  onChange={handleFilterLocationChange}
                  label="Location"
                >
                  <MenuItem value="all">All Locations</MenuItem>
                  <MenuItem value="kinshasa">Kinshasa</MenuItem>
                  <MenuItem value="lubumbashi">Lubumbashi</MenuItem>
                  <MenuItem value="goma">Goma</MenuItem>
                  <MenuItem value="bukavu">Bukavu</MenuItem>
                  <MenuItem value="kisangani">Kisangani</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Box>
              <Typography variant="subtitle1" component="span" sx={{ mr: 2 }}>
                SORT BY:
              </Typography>
              <Button variant="contained" size="small" sx={{ mr: 1 }}>NEWEST</Button>
              <Button size="small" sx={{ mr: 1 }}>BEST RATE</Button>
              <Button size="small">EXPIRING SOON</Button>
            </Box>
            
            <Button variant="contained">
              APPLY FILTERS
            </Button>
          </Box>
        </Paper>
        
        {/* Active Exchange Requests */}
        <Grid container spacing={3}>
          {[
            {
              from: "USD",
              to: "CDF",
              amount: "$500",
              rate: "2,450",
              total: "1,225,000 CDF",
              location: "Kinshasa (Gombe)",
              available: "Today, 2PM - 6PM",
              expires: "18 hours",
              user: "Jean K.",
              verified: true,
              exchanges: 15
            },
            {
              from: "EUR",
              to: "CDF",
              amount: "€300",
              rate: "2,680",
              total: "804,000 CDF",
              location: "Lubumbashi (Centre-ville)",
              available: "Tomorrow, 10AM - 2PM",
              expires: "36 hours",
              user: "Marie T.",
              verified: true,
              exchanges: 8
            },
            {
              from: "CDF",
              to: "USD",
              amount: "850,000 CDF",
              rate: "2,430",
              total: "$350",
              location: "Kinshasa (Gombe)",
              available: "Today, 3PM - 7PM",
              expires: "10 hours",
              user: "Patrick M.",
              verified: true,
              exchanges: 12
            }
          ].map((exchange, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Card sx={{ height: '100%' }}>
                <CardContent>
                  <Typography variant="h6" component="h3" gutterBottom align="center">
                    {exchange.from} → {exchange.to}
                  </Typography>
                  
                  <Box sx={{ my: 2 }}>
                    <Typography variant="body1" gutterBottom>
                      <strong>Amount:</strong> {exchange.amount}
                    </Typography>
                    <Typography variant="body1" gutterBottom>
                      <strong>Rate:</strong> {exchange.rate} CDF per {exchange.from}
                    </Typography>
                    <Typography variant="body1" gutterBottom>
                      <strong>Total:</strong> {exchange.total}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ mb: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                      <LocationOnIcon fontSize="small" sx={{ mr: 0.5 }} />
                      <Typography variant="body2">
                        {exchange.location}
                      </Typography>
                    </Box>
                    
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                      <AccessTimeIcon fontSize="small" sx={{ mr: 0.5 }} />
                      <Typography variant="body2">
                        Available: {exchange.available}
                      </Typography>
                    </Box>
                    
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <AccessTimeIcon fontSize="small" sx={{ mr: 0.5 }} />
                      <Typography variant="body2">
                        Expires in: {exchange.expires}
                      </Typography>
                    </Box>
                  </Box>
                  
                  <Box sx={{ mt: 2 }}>
                    <Typography variant="body2">
                      Posted by: {exchange.user} {exchange.verified && "✓"} | {exchange.exchanges} successful exchanges
                    </Typography>
                  </Box>
                </CardContent>
                <CardActions sx={{ justifyContent: 'space-between', px: 2, pb: 2 }}>
                  <Button variant="outlined">CONTACT</Button>
                  <Button variant="contained">VIEW DETAILS</Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
        
        {/* Pagination */}
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <Button variant="contained" size="small" sx={{ mx: 0.5 }}>1</Button>
          <Button size="small" sx={{ mx: 0.5 }}>2</Button>
          <Button size="small" sx={{ mx: 0.5 }}>3</Button>
          <Typography sx={{ mx: 0.5 }}>...</Typography>
          <Button size="small" sx={{ mx: 0.5 }}>Next &gt;</Button>
        </Box>
        
        {/* Exchange Safety Guidelines */}
        <Paper sx={{ p: 4, mb: 4 }}>
          <Typography variant="h5" component="h3" gutterBottom>
            EXCHANGE SAFETY GUIDELINES
          </Typography>
          <Box component="ul" sx={{ pl: 4 }}>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Always meet in public places (banks, coffee shops, hotel lobbies)</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Verify the identity of your exchange partner</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Count money carefully before completing the exchange</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Consider bringing a friend for larger transactions</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Report any suspicious behavior to platform moderators</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 2 }}>Use the platform's reputation system to evaluate exchange partners</Typography>
            </Box>
          </Box>
          <Button variant="outlined">
            VIEW FULL SAFETY GUIDELINES
          </Button>
        </Paper>
        
        {/* My Exchange Requests Section */}
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h5" component="h3" gutterBottom>
            MY EXCHANGE REQUESTS
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
            <Button variant="contained">VIEW MY ACTIVE REQUESTS</Button>
            <Button variant="outlined">VIEW MY EXCHANGE HISTORY</Button>
          </Box>
        </Paper>
      </Container>
      
      {/* Footer */}
      <Box sx={{ bgcolor: 'primary.dark', color: 'white', py: 6, mt: 8 }}>
        <Container>
          <Typography variant="h5" component="div" gutterBottom align="center">
            Congo Diaspora Platform
          </Typography>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">ABOUT US</Button>
            <Button color="inherit">CONTACT</Button>
            <Button color="inherit">PRIVACY POLICY</Button>
            <Button color="inherit">TERMS OF SERVICE</Button>
            <Button color="inherit">FAQ</Button>
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">FRANÇAIS</Button>
            <Button color="inherit">LINGALA</Button>
            <Button color="inherit">ENGLISH</Button>
            <Button color="inherit">SWAHILI</Button>
            <Button color="inherit">TSHILUBA</Button>
          </Box>
          
          <Typography variant="body2" align="center" sx={{ mt: 4 }}>
            © 2025 Congo Diaspora Platform. All rights reserved.
          </Typography>
        </Container>
      </Box>
    </>
  );
}
