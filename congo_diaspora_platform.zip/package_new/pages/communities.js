import React from 'react';
import { 
  AppBar, 
  Toolbar, 
  Typography, 
  Button, 
  Container, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  CardActions,
  TextField,
  Paper,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  Avatar
} from '@mui/material';
import { 
  Search as SearchIcon,
  WhatsApp as WhatsAppIcon,
  AccessTime as AccessTimeIcon,
  Comment as CommentIcon,
  ThumbUp as ThumbUpIcon,
  Share as ShareIcon
} from '@mui/icons-material';

export default function Communities() {
  const [language, setLanguage] = React.useState('fr');
  const [community, setCommunity] = React.useState('kinshasa');
  const [postType, setPostType] = React.useState('all');
  const [sortBy, setSortBy] = React.useState('new');

  const handleLanguageChange = (event) => {
    setLanguage(event.target.value);
  };

  const handleCommunityChange = (event) => {
    setCommunity(event.target.value);
  };

  const handlePostTypeChange = (event) => {
    setPostType(event.target.value);
  };

  const handleSortByChange = (event) => {
    setSortBy(event.target.value);
  };

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Congo Diaspora Platform
          </Typography>
          
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
              <Select
                value={language}
                onChange={handleLanguageChange}
                displayEmpty
                sx={{ color: 'white' }}
              >
                <MenuItem value="fr">Français</MenuItem>
                <MenuItem value="ln">Lingala</MenuItem>
                <MenuItem value="en">English</MenuItem>
                <MenuItem value="sw">Swahili</MenuItem>
                <MenuItem value="lu">Tshiluba</MenuItem>
              </Select>
            </FormControl>
            
            <Button color="inherit">
              <SearchIcon sx={{ mr: 1 }} />
              Search
            </Button>
            
            <Button color="inherit">Login</Button>
            <Button variant="contained" color="secondary">Sign Up</Button>
          </Box>
        </Toolbar>
      </AppBar>
      
      <Box sx={{ bgcolor: '#f5f5f5', py: 2 }}>
        <Container>
          <Grid container spacing={2}>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/">Home</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth variant="contained" href="/communities">Communities</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/businesses">Businesses</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/exchange">Exchange</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/services">Services</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/profile">My Profile</Button>
            </Grid>
          </Grid>
        </Container>
      </Box>
      
      {/* Community Header */}
      <Box sx={{ 
        bgcolor: 'primary.main', 
        color: 'white', 
        py: 4
      }}>
        <Container>
          <Typography variant="h3" component="h1" gutterBottom align="center">
            r/Kinshasa
          </Typography>
          <Typography variant="h6" align="center" sx={{ maxWidth: 800, mx: 'auto' }}>
            15.2k members • Created Jan 2025
          </Typography>
          <Typography variant="body1" align="center" sx={{ maxWidth: 800, mx: 'auto', mt: 2 }}>
            Regional community for Kinshasa-related discussions, services, and connections for returning diaspora professionals.
          </Typography>
        </Container>
      </Box>
      
      <Container sx={{ my: 4 }}>
        <Grid container spacing={3}>
          {/* Main Content */}
          <Grid item xs={12} md={8}>
            {/* Create Post */}
            <Paper sx={{ p: 3, mb: 4 }}>
              <Typography variant="h6" gutterBottom>
                CREATE POST
              </Typography>
              <TextField
                fullWidth
                placeholder="Title"
                variant="outlined"
                sx={{ mb: 2 }}
              />
              <TextField
                fullWidth
                placeholder="What's on your mind?"
                variant="outlined"
                multiline
                rows={4}
                sx={{ mb: 2 }}
              />
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <FormControl sx={{ minWidth: 200 }}>
                  <InputLabel>Post Type</InputLabel>
                  <Select
                    value="discussion"
                    label="Post Type"
                  >
                    <MenuItem value="discussion">Discussion</MenuItem>
                    <MenuItem value="question">Question</MenuItem>
                    <MenuItem value="resource">Resource</MenuItem>
                    <MenuItem value="event">Event</MenuItem>
                    <MenuItem value="service">Service Request</MenuItem>
                  </Select>
                </FormControl>
                <Button variant="contained">POST</Button>
              </Box>
            </Paper>
            
            {/* Filter and Sort */}
            <Paper sx={{ p: 2, mb: 4 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box>
                  <Button 
                    variant={sortBy === 'new' ? 'contained' : 'text'} 
                    onClick={() => setSortBy('new')}
                    sx={{ mr: 1 }}
                  >
                    NEW
                  </Button>
                  <Button 
                    variant={sortBy === 'hot' ? 'contained' : 'text'} 
                    onClick={() => setSortBy('hot')}
                    sx={{ mr: 1 }}
                  >
                    HOT
                  </Button>
                  <Button 
                    variant={sortBy === 'top' ? 'contained' : 'text'} 
                    onClick={() => setSortBy('top')}
                  >
                    TOP
                  </Button>
                </Box>
                
                <FormControl sx={{ minWidth: 150 }}>
                  <InputLabel>Filter By</InputLabel>
                  <Select
                    value={postType}
                    onChange={handlePostTypeChange}
                    label="Filter By"
                  >
                    <MenuItem value="all">All Posts</MenuItem>
                    <MenuItem value="discussion">Discussions</MenuItem>
                    <MenuItem value="question">Questions</MenuItem>
                    <MenuItem value="resource">Resources</MenuItem>
                    <MenuItem value="event">Events</MenuItem>
                    <MenuItem value="service">Service Requests</MenuItem>
                  </Select>
                </FormControl>
              </Box>
            </Paper>
            
            {/* Posts */}
            {[
              {
                title: "Recommended areas for families in Kinshasa",
                author: "u/MarieT",
                time: "8 hours ago",
                type: "SERVICE REQUEST",
                content: "I'm returning to Kinshasa after 12 years in France with my family (2 children ages 8 and 10). Looking for safe neighborhoods with good schools nearby. Budget around $1200/month. Any recommendations?",
                upvotes: 24,
                comments: 15
              },
              {
                title: "List of reliable administrative service providers",
                author: "u/PatrickM",
                time: "2 days ago",
                type: "RESOURCE",
                content: "I've compiled a list of reliable administrative service providers in Kinshasa that can help with document processing, permits, and other bureaucratic procedures. All have been personally verified or recommended by multiple community members.",
                upvotes: 87,
                comments: 32
              },
              {
                title: "Monthly Kinshasa Networking Event - April 15",
                author: "u/CommunityMod",
                time: "1 day ago",
                type: "EVENT",
                content: "Join us for our monthly networking event for Congolese professionals! This month's focus: Tech and Innovation. Location: Hotel Pullman, 7PM-10PM. RSVP required (link in post)",
                upvotes: 45,
                comments: 28
              },
              {
                title: "Housing Market Update - April 2025",
                author: "u/RealEstateExpert",
                time: "3 days ago",
                type: "DISCUSSION",
                content: "The housing market in Kinshasa has seen significant changes in the past quarter. Prices in Gombe and Lingwala have increased by 15%, while areas like Ngaliema offer better value. New developments in Kintambo are worth considering for long-term investment.",
                upvotes: 62,
                comments: 41
              }
            ].map((post, index) => (
              <Paper sx={{ p: 3, mb: 3 }} key={index}>
                {post.type === "SERVICE REQUEST" && (
                  <Chip 
                    icon={<AccessTimeIcon />} 
                    label="24h" 
                    color="warning" 
                    size="small" 
                    sx={{ mb: 1 }}
                  />
                )}
                
                <Typography variant="h6" component="h2" gutterBottom>
                  {post.title}
                </Typography>
                
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    Posted by: {post.author} | {post.time}
                  </Typography>
                  <Chip 
                    label={post.type} 
                    size="small" 
                    sx={{ ml: 2 }}
                    color={
                      post.type === "SERVICE REQUEST" ? "warning" : 
                      post.type === "RESOURCE" ? "success" :
                      post.type === "EVENT" ? "info" :
                      "default"
                    }
                  />
                </Box>
                
                <Typography variant="body1" sx={{ mb: 3 }}>
                  {post.content}
                </Typography>
                
                <Box sx={{ display: 'flex', gap: 2 }}>
                  <Button startIcon={<ThumbUpIcon />} variant="text">
                    {post.upvotes}
                  </Button>
                  <Button startIcon={<CommentIcon />} variant="text">
                    {post.comments} Comments
                  </Button>
                  <Button startIcon={<ShareIcon />} variant="text">
                    Share
                  </Button>
                  {post.type === "SERVICE REQUEST" && (
                    <Box sx={{ display: 'flex', ml: 'auto', gap: 2 }}>
                      <Button variant="outlined" startIcon={<WhatsAppIcon />} color="success">
                        Contact
                      </Button>
                      <Button variant="contained">
                        Respond
                      </Button>
                    </Box>
                  )}
                </Box>
              </Paper>
            ))}
            
            {/* Pagination */}
            <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
              <Button variant="contained" size="small" sx={{ mx: 0.5 }}>1</Button>
              <Button size="small" sx={{ mx: 0.5 }}>2</Button>
              <Button size="small" sx={{ mx: 0.5 }}>3</Button>
              <Typography sx={{ mx: 0.5 }}>...</Typography>
              <Button size="small" sx={{ mx: 0.5 }}>Next &gt;</Button>
            </Box>
          </Grid>
          
          {/* Sidebar */}
          <Grid item xs={12} md={4}>
            <Paper sx={{ p: 3, mb: 4 }}>
              <Typography variant="h6" component="h3" gutterBottom>
                ABOUT COMMUNITY
              </Typography>
              <Typography variant="body2" sx={{ mb: 3 }}>
                Regional community for Kinshasa-related discussions, services, and connections for returning diaspora professionals.
              </Typography>
              <Divider sx={{ my: 2 }} />
              <Typography variant="body2" sx={{ mb: 1 }}>
                <strong>Created:</strong> January 15, 2025
              </Typography>
              <Typography variant="body2" sx={{ mb: 1 }}>
                <strong>Members:</strong> 15,243
              </Typography>
              <Typography variant="body2" sx={{ mb: 3 }}>
                <strong>Online Now:</strong> 342
              </Typography>
              <Button variant="contained" fullWidth>
                JOIN COMMUNITY
              </Button>
            </Paper>
            
            <Paper sx={{ p: 3, mb: 4 }}>
              <Typography variant="h6" component="h3" gutterBottom>
                COMMUNITY RULES
              </Typography>
              <Box component="ol" sx={{ pl: 3 }}>
                <Box component="li" sx={{ mb: 1 }}>
                  <Typography variant="body2">Be respectful and constructive</Typography>
                </Box>
                <Box component="li" sx={{ mb: 1 }}>
                  <Typography variant="body2">No political discussions</Typography>
                </Box>
                <Box component="li" sx={{ mb: 1 }}>
                  <Typography variant="body2">Verify information before posting</Typography>
                </Box>
                <Box component="li" sx={{ mb: 1 }}>
                  <Typography variant="body2">No self-promotion</Typography>
                </Box>
                <Box component="li" sx={{ mb: 1 }}>
                  <Typography variant="body2">Service requests must be specific</Typography>
                </Box>
              </Box>
            </Paper>
            
            <Paper sx={{ p: 3, mb: 4 }}>
              <Typography variant="h6" component="h3" gutterBottom>
                MODERATORS
              </Typography>
              <Box sx={{ mb: 2 }}>
                {['u/CommunityMod', 'u/KinshasaExpert', 'u/DiasporaLiaison'].map((mod, index) => (
                  <Box key={index} sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <Typography variant="body2" sx={{ ml: 1 }}>• {mod}</Typography>
                  </Box>
                ))}
              </Box>
              <Button variant="outlined" fullWidth size="small">
                MESSAGE MODS
              </Button>
            </Paper>
            
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" component="h3" gutterBottom>
                RELATED COMMUNITIES
              </Typography>
              <Box sx={{ mb: 2 }}>
                {['r/CongoHousing', 'r/CongoFinance', 'r/CongoEducation'].map((community, index) => (
                  <Box key={index} sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <Typography variant="body2" sx={{ ml: 1 }}>• {community}</Typography>
                  </Box>
                ))}
              </Box>
              <Button variant="outlined" fullWidth size="small">
                VIEW ALL COMMUNITIES
              </Button>
            </Paper>
          </Grid>
        </Grid>
      </Container>
      
      {/* Footer */}
      <Box sx={{ bgcolor: 'primary.dark', color: 'white', py: 6, mt: 8 }}>
        <Container>
          <Typography variant="h5" component="div" gutterBottom align="center">
            Congo Diaspora Platform
          </Typography>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">ABOUT US</Button>
            <Button color="inherit">CONTACT</Button>
            <Button color="inherit">PRIVACY POLICY</Button>
            <Button color="inherit">TERMS OF SERVICE</Button>
            <Button color="inherit">FAQ</Button>
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">FRANÇAIS</Button>
            <Button color="inherit">LINGALA</Button>
            <Button color="inherit">ENGLISH</Button>
            <Button color="inherit">SWAHILI</Button>
            <Button color="inherit">TSHILUBA</Button>
          </Box>
          
          <Typography variant="body2" align="center" sx={{ mt: 4 }}>
            © 2025 Congo Diaspora Platform. All rights reserved.
          </Typography>
        </Container>
      </Box>
    </>
  );
}
