import React from 'react';
import { 
  AppBar, 
  Toolbar, 
  Typography, 
  Button, 
  Container, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  CardActions,
  TextField,
  Paper,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  Rating
} from '@mui/material';
import { 
  Search as SearchIcon,
  WhatsApp as WhatsAppIcon,
  LocationOn as LocationOnIcon,
  VerifiedUser as VerifiedUserIcon
} from '@mui/icons-material';

export default function Businesses() {
  const [language, setLanguage] = React.useState('fr');
  const [category, setCategory] = React.useState('all');
  const [location, setLocation] = React.useState('all');
  const [rating, setRating] = React.useState('any');
  const [verifiedOnly, setVerifiedOnly] = React.useState(false);

  const handleLanguageChange = (event) => {
    setLanguage(event.target.value);
  };

  const handleCategoryChange = (event) => {
    setCategory(event.target.value);
  };

  const handleLocationChange = (event) => {
    setLocation(event.target.value);
  };

  const handleRatingChange = (event) => {
    setRating(event.target.value);
  };

  const handleVerifiedChange = (event) => {
    setVerifiedOnly(event.target.checked);
  };

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Congo Diaspora Platform
          </Typography>
          
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
              <Select
                value={language}
                onChange={handleLanguageChange}
                displayEmpty
                sx={{ color: 'white' }}
              >
                <MenuItem value="fr">Français</MenuItem>
                <MenuItem value="ln">Lingala</MenuItem>
                <MenuItem value="en">English</MenuItem>
                <MenuItem value="sw">Swahili</MenuItem>
                <MenuItem value="lu">Tshiluba</MenuItem>
              </Select>
            </FormControl>
            
            <Button color="inherit">
              <SearchIcon sx={{ mr: 1 }} />
              Search
            </Button>
            
            <Button color="inherit">Login</Button>
            <Button variant="contained" color="secondary">Sign Up</Button>
          </Box>
        </Toolbar>
      </AppBar>
      
      <Box sx={{ bgcolor: '#f5f5f5', py: 2 }}>
        <Container>
          <Grid container spacing={2}>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/">Home</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/communities">Communities</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth variant="contained" href="/businesses">Businesses</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/exchange">Exchange</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/services">Services</Button>
            </Grid>
            <Grid item xs={12} md={2}>
              <Button fullWidth href="/profile">My Profile</Button>
            </Grid>
          </Grid>
        </Container>
      </Box>
      
      {/* Business Directory Header */}
      <Box sx={{ 
        bgcolor: 'primary.main', 
        color: 'white', 
        py: 4
      }}>
        <Container>
          <Typography variant="h3" component="h1" gutterBottom align="center">
            BUSINESS DIRECTORY
          </Typography>
          <Typography variant="h6" align="center" sx={{ maxWidth: 800, mx: 'auto' }}>
            Find trusted and verified businesses rated by the Congolese diaspora community
          </Typography>
        </Container>
      </Box>
      
      <Container sx={{ my: 4 }}>
        {/* Search and Filter Section */}
        <Paper sx={{ p: 3, mb: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
            <TextField
              fullWidth
              placeholder="Search businesses..."
              variant="outlined"
              sx={{ mr: 2 }}
            />
            <Button variant="contained" startIcon={<SearchIcon />}>
              SEARCH
            </Button>
          </Box>
          
          <Typography variant="h6" gutterBottom>
            FILTER BY:
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <InputLabel>Category</InputLabel>
                <Select
                  value={category}
                  onChange={handleCategoryChange}
                  label="Category"
                >
                  <MenuItem value="all">All Categories</MenuItem>
                  <MenuItem value="housing">Housing</MenuItem>
                  <MenuItem value="finance">Financial Services</MenuItem>
                  <MenuItem value="education">Education</MenuItem>
                  <MenuItem value="healthcare">Healthcare</MenuItem>
                  <MenuItem value="legal">Legal Services</MenuItem>
                  <MenuItem value="admin">Administrative</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <InputLabel>Location</InputLabel>
                <Select
                  value={location}
                  onChange={handleLocationChange}
                  label="Location"
                >
                  <MenuItem value="all">All Locations</MenuItem>
                  <MenuItem value="kinshasa">Kinshasa</MenuItem>
                  <MenuItem value="lubumbashi">Lubumbashi</MenuItem>
                  <MenuItem value="goma">Goma</MenuItem>
                  <MenuItem value="bukavu">Bukavu</MenuItem>
                  <MenuItem value="kisangani">Kisangani</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <InputLabel>Rating</InputLabel>
                <Select
                  value={rating}
                  onChange={handleRatingChange}
                  label="Rating"
                >
                  <MenuItem value="any">Any Rating</MenuItem>
                  <MenuItem value="5">5 Stars</MenuItem>
                  <MenuItem value="4">4+ Stars</MenuItem>
                  <MenuItem value="3">3+ Stars</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ display: 'flex', alignItems: 'center', height: '100%' }}>
                <input
                  type="checkbox"
                  id="verified-only"
                  checked={verifiedOnly}
                  onChange={handleVerifiedChange}
                  style={{ marginRight: '8px' }}
                />
                <label htmlFor="verified-only">Show only verified businesses</label>
              </Box>
            </Grid>
          </Grid>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
            <Button variant="contained" size="large">
              APPLY FILTERS
            </Button>
          </Box>
        </Paper>
        
        {/* Category Quick Links */}
        <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: 2, mb: 4 }}>
          <Button variant="outlined">HOUSING</Button>
          <Button variant="outlined">FINANCE</Button>
          <Button variant="outlined">EDUCATION</Button>
          <Button variant="outlined">HEALTHCARE</Button>
          <Button variant="outlined">LEGAL</Button>
          <Button variant="outlined">MORE ▼</Button>
        </Box>
        
        {/* Business Listings */}
        {[
          {
            name: "Congo Relocation Services",
            logo: "CRS",
            verified: true,
            rating: 4.9,
            reviews: 127,
            category: "Housing",
            location: "Kinshasa",
            description: "Specializing in helping diaspora professionals find suitable housing upon return to Congo. Services include property tours, lease negotiation, and relocation assistance."
          },
          {
            name: "Diaspora Financial Advisors",
            logo: "DFA",
            verified: true,
            rating: 4.7,
            reviews: 98,
            category: "Financial Services",
            location: "Multiple Locations",
            description: "Financial advisory services for returning diaspora members. Investment planning, banking setup, and currency exchange guidance."
          },
          {
            name: "Express Document Services",
            logo: "EDS",
            verified: true,
            rating: 4.6,
            reviews: 112,
            category: "Administrative",
            location: "Kinshasa",
            description: "Expedited processing of government documents, permits, and licenses. Specializing in returning diaspora documentation needs."
          },
          {
            name: "Kinshasa International School",
            logo: "KIS",
            verified: false,
            rating: 4.5,
            reviews: 85,
            category: "Education",
            location: "Kinshasa",
            description: "International curriculum school with programs designed to help children of returning diaspora adapt to life in Congo while maintaining international educational standards."
          }
        ].map((business, index) => (
          <Paper sx={{ p: 3, mb: 3 }} key={index}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={2} md={1}>
                <Box sx={{ 
                  width: 60, 
                  height: 60, 
                  bgcolor: 'primary.main', 
                  color: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderRadius: 1,
                  fontSize: '1.2rem',
                  fontWeight: 'bold'
                }}>
                  {business.logo}
                </Box>
              </Grid>
              
              <Grid item xs={12} sm={10} md={11}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
                  <Typography variant="h6" component="h3">
                    {business.name}
                  </Typography>
                  
                  {business.verified && (
                    <Chip 
                      icon={<VerifiedUserIcon />} 
                      label="VERIFIED" 
                      color="success" 
                      size="small" 
                    />
                  )}
                </Box>
                
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Rating value={business.rating} precision={0.1} readOnly size="small" />
                  <Typography variant="body2" sx={{ ml: 1 }}>
                    ({business.rating}) | {business.category} | {business.location} | {business.reviews} reviews
                  </Typography>
                </Box>
                
                <Typography variant="body1" sx={{ mb: 2 }}>
                  {business.description}
                </Typography>
                
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                  <Button variant="outlined">VIEW PROFILE</Button>
                  <Button 
                    variant="contained" 
                    startIcon={<WhatsAppIcon />}
                    color="success"
                  >
                    CONTACT VIA WHATSAPP
                  </Button>
                  <Button variant="text">SAVE</Button>
                </Box>
              </Grid>
            </Grid>
          </Paper>
        ))}
        
        {/* Pagination */}
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <Button variant="contained" size="small" sx={{ mx: 0.5 }}>1</Button>
          <Button size="small" sx={{ mx: 0.5 }}>2</Button>
          <Button size="small" sx={{ mx: 0.5 }}>3</Button>
          <Typography sx={{ mx: 0.5 }}>...</Typography>
          <Button size="small" sx={{ mx: 0.5 }}>Next &gt;</Button>
        </Box>
        
        {/* Add Business Section */}
        <Paper sx={{ p: 4, mb: 4, textAlign: 'center' }}>
          <Typography variant="h5" component="h3" gutterBottom>
            OWN A BUSINESS?
          </Typography>
          <Typography variant="body1" sx={{ mb: 3, maxWidth: 600, mx: 'auto' }}>
            Add your business to our directory to connect with returning diaspora professionals
          </Typography>
          <Button variant="contained" color="secondary" size="large">
            ADD YOUR BUSINESS
          </Button>
        </Paper>
        
        {/* Business Verification Information */}
        <Paper sx={{ p: 4 }}>
          <Typography variant="h5" component="h3" gutterBottom>
            ABOUT BUSINESS VERIFICATION
          </Typography>
          <Typography variant="body1" sx={{ mb: 3 }}>
            Verified businesses have undergone our verification process to confirm their legitimacy and quality of service. Verification includes:
          </Typography>
          <Box component="ul" sx={{ pl: 4 }}>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Document verification</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Physical location confirmation</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 1 }}>Client testimonials</Typography>
            </Box>
            <Box component="li">
              <Typography variant="body1" sx={{ mb: 3 }}>Compliance with platform standards</Typography>
            </Box>
          </Box>
          <Button variant="outlined">
            LEARN MORE ABOUT VERIFICATION
          </Button>
        </Paper>
      </Container>
      
      {/* Footer */}
      <Box sx={{ bgcolor: 'primary.dark', color: 'white', py: 6, mt: 8 }}>
        <Container>
          <Typography variant="h5" component="div" gutterBottom align="center">
            Congo Diaspora Platform
          </Typography>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">ABOUT US</Button>
            <Button color="inherit">CONTACT</Button>
            <Button color="inherit">PRIVACY POLICY</Button>
            <Button color="inherit">TERMS OF SERVICE</Button>
            <Button color="inherit">FAQ</Button>
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">FRANÇAIS</Button>
            <Button color="inherit">LINGALA</Button>
            <Button color="inherit">ENGLISH</Button>
            <Button color="inherit">SWAHILI</Button>
            <Button color="inherit">TSHILUBA</Button>
          </Box>
          
          <Typography variant="body2" align="center" sx={{ mt: 4 }}>
            © 2025 Congo Diaspora Platform. All rights reserved.
          </Typography>
        </Container>
      </Box>
    </>
  );
}
