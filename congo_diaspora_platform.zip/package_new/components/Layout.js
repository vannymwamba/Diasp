import React from 'react';
import { 
  Box, 
  Container, 
  Button,
  Link
} from '@mui/material';

export default function Layout({ children }) {
  return (
    <>
      {children}
      
      <Box sx={{ bgcolor: 'primary.dark', color: 'white', py: 6, mt: 8 }}>
        <Container>
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">ABOUT US</Button>
            <Button color="inherit">CONTACT</Button>
            <Button color="inherit">PRIVACY POLICY</Button>
            <Button color="inherit">TERMS OF SERVICE</Button>
            <Button color="inherit">FAQ</Button>
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', my: 3 }}>
            <Button color="inherit">FRANÇAIS</Button>
            <Button color="inherit">LINGALA</Button>
            <Button color="inherit">ENGLISH</Button>
            <Button color="inherit">SWAHILI</Button>
            <Button color="inherit">TSHILUBA</Button>
          </Box>
        </Container>
      </Box>
    </>
  );
}
